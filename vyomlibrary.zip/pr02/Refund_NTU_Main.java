package kli.org.ntuione.pr02;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import org.apache.poi.ss.usermodel.Row;

import all.org.vyomlibrary.MailSendToCustomer;
import all.org.vyomlibrary.VyomExcelHandler;
import all.org.vyomlibrary.VyomSeleniumHandler;


/**
 * 
 * @author Sachin M LO5015s
 * Refund NTU Process
 *
 */

public class Refund_NTU_Main 
{
	static VyomSeleniumHandler webHandler = new VyomSeleniumHandler();
	static VyomExcelHandler xlsHandler = new VyomExcelHandler();
	public static Logger log = Logger.getLogger(Refund_NTU_Main.class.getName());//Log file obj
	static boolean siteDown_urlChangeFlag = false;
	static boolean siteDown = false;
	static boolean serverError_Check = false;

	public static void createLogFile() throws SecurityException, IOException
	{
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH-mm-ss");
		FileHandler fh = new FileHandler("LogFiles/Refund_NTU_Main_" + sdf.format(Calendar.getInstance().getTime()) + ".log");
		fh.setFormatter(new SimpleFormatter());
		log.addHandler(fh);

	}//End of createLogFile

	public static void readExcel(String allocationUserName, String mailSendTo) throws Exception
	{
		try
		{
			xlsHandler.getExcelFile(VyomSeleniumHandler.getProperties("InputFilePath"));//Input File
			Iterator<Row> iterator = xlsHandler.readSheet.iterator();

			while(iterator.hasNext())
			{
				Row row = iterator.next();
				if(row.getRowNum() == 0)
				{
					xlsHandler.createCell(row, 3, "Bot_Remark");//2
					xlsHandler.createCell(row, 4, "Proc_Time");//3

				}else if(row.getRowNum() > 0)
				{
					String policyNo = "";
					String ntuType = "";
					String medicalChangesFromUser = "";
					String medicalChanges = "";
					String bot_Remark = "";
					String procRemark = "";
					String procTime = "";

					bot_Remark = xlsHandler.getCell(row, 3);//Check bot remark

					if(bot_Remark.equals(""))
					{
						policyNo = xlsHandler.getNumericCellValue(row, 0);//Get Policy No
						log.info("Policy No :"+policyNo);

						ntuType = xlsHandler.getCell(row, 1);//Get Status
						log.info("NTU Status :"+ntuType);

						medicalChangesFromUser = xlsHandler.getNumericCellValue(row, 2);//Get Medical Charges
						log.info("Medical Charges from User :"+medicalChangesFromUser);
						medicalChanges = medicalChangesFromUser.replaceAll("\u00A0", "").trim();//Remove blank space
						log.info("Medical Charges :"+medicalChanges);

						if(policyNo != "" && ntuType != "")
						{
							if(serverError_Check == false)
							{
								procRemark = NTU_IOne.CaseProcessing(allocationUserName, policyNo, ntuType, medicalChanges, log);//Calling function
								log.info("Processing Remark :"+procRemark);

								xlsHandler.createCell(row, 3, procRemark);//Update Remark

								SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
								procTime = sdf.format(new Date());

								xlsHandler.createCell(row, 4, procTime);//Update Remark
								xlsHandler.updateRemark(VyomSeleniumHandler.getProperties("InputFilePath"));//Save file

								if(procRemark.contains("Please Choose Combo Cases to complete:"))
								{
									log.info("Combo case error found, break the process");

									NTU_IOne.textFileRemarkWrite(procRemark, log);//Text remark
									String mailBody = "Dear Team, \n\n    Refund NTU Process_PR02 process failed due to combo error. Please find attached file for reference.\n\nRegards,\nRobotics Team.\nKotak Life";
									MailSendToCustomer.sendMail_With_Attachemnt("Refund NTU Process_PR02 Failed: Combo cases error found", 
											mailBody,"InputFile.xls", VyomSeleniumHandler.getProperties("InputFilePath"), mailSendTo, log);

									webHandler.clearDriverInstances();//clearing ie instance
									log.info("--------------------------------------End Process------------------------------------");
									System.exit(-1);					
								}

								if(procRemark.equalsIgnoreCase("Ione Site Is Down, Due to Server Error Found") && siteDown == false)
								{
									log.info("Inside site down check");
									siteDown = true;
									siteDown_urlChangeFlag = true;
									log.info("Ione Site Is Down, Due to Server Error Found, Site down check remark :"+siteDown_urlChangeFlag);
									webHandler.clearDriverInstances();
									throw new Exception();
								}//URL Change

								log.info("Site Down flag :"+siteDown);
								log.info("SiteDown_urlChangeFlag inside main:"+siteDown_urlChangeFlag);

								if(procRemark.equalsIgnoreCase("Ione Site Is Down, Due to Server Error Found"))//After url change again if URL down then further cases not processed
								{
									serverError_Check = true;
									NTU_IOne.textFileRemarkWrite("Second Ione URL Is Down, Due to Server Error Found.", log);//Text remark
									log.info("Second Ione URL Is Down, Due to Server Error Found. serverError_Check flag is :"+serverError_Check);
								}
								
							}else
							{
								log.info("Ione Site Is Down after changing second url, further cases are not processed");
								xlsHandler.createCell(row, 3, "CPC and Beta both sites are down. kindly re-trigger after some time");//Update Remark

								NTU_IOne.textFileRemarkWrite("CPC and Beta both sites are down. kindly re-trigger after some time", log);//Text remark

								SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
								procTime = sdf.format(new Date());

								xlsHandler.createCell(row, 4, procTime);//Update procTime
								xlsHandler.updateRemark(VyomSeleniumHandler.getProperties("InputFilePath"));
							}
						}else
						{
							log.info("Blank data present in input file, exit from excel");
							break;
						}
					}
				}
			}
		}catch(Exception e)
		{
			xlsHandler.updateRemark(VyomSeleniumHandler.getProperties("InputFilePath"));
			log.info("Error in excel file reading :"+e);
			throw e;
		}

	}//End of readExcel

	public static void main(String args[]) throws Exception
	{

		String userName = args[0];
		String passWord = args[1];			
		String mailSendTo = args[2];
		String allocation_UserName = "KLI BOT (LO5005)";				

		boolean reTryProcess = true;
		int retryCount = 0;

		siteDown_urlChangeFlag = false;
		siteDown = false;
		serverError_Check = false;

		createLogFile();

		log.info("------------------------------------------------Start Process--------------------------------------------------");
		webHandler.clearDriverInstances();

		while(reTryProcess && retryCount <= Integer.parseInt(VyomSeleniumHandler.getProperties("reTryCount")))
		{
			try
			{
				webHandler.clearDriverInstances();
				webHandler.getDriver();	
				NTU_IOne.login(userName, passWord, mailSendTo, log);

				readExcel(allocation_UserName, mailSendTo);

				reTryProcess = false;
				NTU_IOne.logOut(log);	

				log.info("----------------------------------------------End Process----------------------------------------------------");

			}catch(Exception e)
			{
				log.info("Retry Count is :"+retryCount);
				log.info("Error in Main :"+e);
				webHandler.clearDriverInstances();
				retryCount ++;
			}

			if(retryCount == Integer.parseInt(VyomSeleniumHandler.getProperties("reTryCount")))
			{
				try 
				{
					log.info("I-One Site Not Working/Down");
					NTU_IOne.textFileRemarkWrite("I-One Site Not Working/Down", log);//Text remark

					MailSendToCustomer.sendMail_With_Attachemnt(VyomSeleniumHandler.getProperties("Ione_Down_SubjectBody"), 
							VyomSeleniumHandler.getProperties("Ione_Down_MailBody"), 
							"InputFile.xls", VyomSeleniumHandler.getProperties("InputFilePath"), mailSendTo, log);
					webHandler.clearDriverInstances();//clearing ie instance
					System.exit(-1);
				}catch (Exception e) 
				{
					log.info("Error in Mail send :"+e);
				}
			}// End of retryCnt

		}
		webHandler.clearDriverInstances();
	}//End of main
}//End Class

