package kli.org.ntuione.pr02;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.automationedge.ps.core.util.Assert;
import all.org.vyomlibrary.MailSendToCustomer;
import all.org.vyomlibrary.VyomSeleniumHandler;

public class NTU_IOne2
{
	static VyomSeleniumHandler webHandler = new VyomSeleniumHandler();
	static String parentWindow = "";

	public static String login(String username, String password, String mailSendTo, Logger log)	throws Exception
	{
		String remark = "";
		String errorRemark = "";

		try
		{
			log.info("----------------------------------------Inside Login---------------------------------------------------");

			log.info("SiteDown_urlChangeFlag :"+Refund_NTU_Main.siteDown_urlChangeFlag);
			if(Refund_NTU_Main.siteDown_urlChangeFlag)
			{
				webHandler.loadUrl(VyomSeleniumHandler.getProperties("Ione_URL_Beta"));
				log.info("Url Is : Ione Beta :"+VyomSeleniumHandler.getProperties("Ione_URL_Beta"));
			}else
			{
				webHandler.loadUrl(VyomSeleniumHandler.getProperties("Ione_URL_CPC"));
				log.info("Url Is : Ione CPC :"+VyomSeleniumHandler.getProperties("Ione_URL_CPC"));
			}

			webHandler.sendById("ContentPlaceHolder1_txtUserName", username, 90);//User Name
			webHandler.sendById("ContentPlaceHolder1_txtPassword", password, 90);//Password

			webHandler.clickById("ContentPlaceHolder1_btnLogin", 90);//Click on Submit

			webHandler.waitForPageLoad(90, log);
			Thread.sleep(1500);

			errorRemark = webHandler.getByXpath("//*[@id='ContentPlaceHolder1_P_Ctrl_Status1_lblErrMsg']", 90);//Check login success
			if (!errorRemark.equals(""))
			{
				remark = errorRemark;
				MailSendToCustomer.sendMail(VyomSeleniumHandler.getProperties("IoneSubBody_UPassExpire"), 
						VyomSeleniumHandler.getProperties("IoneMailBody_UPassExpire"), mailSendTo, log);//Mail Send
				log.info("Process Terminated due to :" + errorRemark);
				webHandler.clearDriverInstances();
				System.exit(-1);
			}else
			{
				remark = "Login Successfully";
			}
		}catch (Exception e)
		{
			log.info("Error in i_One_Portal Login :" + e);
			Refund_NTU_Main.siteDown_urlChangeFlag = true;
			webHandler.clearDriverInstances();
			throw e;
		}
		return remark;
	}//End of login

	public static String CaseAllocationToUser(String allocationUserName, String policyNo, Logger log) throws Exception
	{
		String remark = "";
		String getPol_Number = "";
		String getPol_Status = "";
		int checkBoxValue = 0;

		try
		{
			log.info("----------------------------------Inside Case Allocation To User---------------------------------------");

			mouseMoveEventClick("//*[@id='mnuInsuranceOnen2']/table/tbody/tr/td[1]/a", "//*[@id='mnuInsuranceOnen9']/td/table/tbody/tr/td/a", log);//Click on inbox
			log.info("Clicked on inbox button");

			Thread.sleep(2000);//Thread required
			
			webHandler.waitForID("ContentPlaceHolder1_txtThreadID", 30);//Wait for ID

			webHandler.clearById("ContentPlaceHolder1_txtThreadID", 40);//Clear field
			webHandler.sendById("ContentPlaceHolder1_txtThreadID", policyNo, 40);//Enter Policy
			webHandler.clickByXpath("//*[@id='ContentPlaceHolder1_searchWorksheet']", 80);//Click on Search
			webHandler.clickByXpath("//*[@id='ContentPlaceHolder1_searchWorksheet']", 80);//Click on Search
			Thread.sleep(2500);
			webHandler.clickByXpath("//*[@id='ContentPlaceHolder1_searchWorksheet']", 80);//Click on Search
			log.info("Clicked on search button");
			webHandler.waitForPageLoad(80, log);

			/*
			 * 
			 * System.out.println("------------1 test -------------"); Thread.sleep(3000);
			 * 
			 * webHandler.clickByXpath("//table/tbody/tr["+2+"]/td[2]/a", 10000);//Click on
			 * show (Error Steep By santosh check)//test need to delete
			 * 
			 * Thread.sleep(2000000);
			 * 
			 * 
			 */
			Thread.sleep(3000);
			List<WebElement> row = webHandler.getTableRowCount("ContentPlaceHolder1_grdWFBox", "tbody", "tr");//Get row count
			log.info("Table Row size inside sase allocation :" + row.size());

			for (int i = 1; i < row.size(); i++) 
			{
				if (webHandler.checkXpath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+i+"]/td[4]"))//Check Xpath
				{
					getPol_Number = webHandler.getByxPath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+i+"]/td[4]");//Get policy Number
					log.info("Policy No from Ione Table :" + getPol_Number);

					getPol_Status = webHandler.getByxPath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+i+"]/td[7]");//Get status
					log.info("Policy Status from Ione Table :" + getPol_Status);

					if ((getPol_Number.equals(policyNo)) && (getPol_Status.equalsIgnoreCase("NB NTU")))
					{
						log.info("Policy and Status are matched with input file details");
						log.info("Policy number from Ione table :" + getPol_Number);
						log.info("Policy status from Ione table :" + getPol_Status);

						checkBoxValue = i - 2;
						webHandler.clickByXpath("//*[@id='ContentPlaceHolder1_grdWFBox_chkbox_" + checkBoxValue + "']", 30);//Select Cases
						webHandler.selectDropDownById("ContentPlaceHolder1_ddlUsers", allocationUserName, 90);//Select Bot Name
						mouseMoveEventClick("//*[@id='ContentPlaceHolder1_mnuWFn0']/table/tbody/tr/td[1]/a", "//*[@id='ContentPlaceHolder1_mnuWFn3']/td/table/tbody/tr/td/a", log);//Move Cases
						Thread.sleep(10000);
						webHandler.waitForPageLoad(80, log);
						
						webHandler.clickByXpath("//*[@id='ContentPlaceHolder1_searchWorksheet']", 90);//Click on Search by Santosh New

						Thread.sleep(3000);

						webHandler.clickByXpath("//*[@id='ContentPlaceHolder1_searchWorksheet']", 90);//Click on Search by Santosh New

//						webHandler.clickByXpath("//*[@id='ContentPlaceHolder1_searchWorksheet']", 90);//Click on Search by Santosh New

						//Thread.sleep(3000);
						
						log.info("Case is Allocated to BOT");
						remark = "Policy Number and Status Found";
						break;
					}
					remark = "Policy number and status not matched while case allocation";
				}
			}
		}catch (Exception e)
		{
			remark = "Case Not Processed in Allocation";
			log.info("Error in CaseAllocationToUser function :" + e);
			throw e;
		}
		return remark;
	}//End of CaseAllocationToUser()

	public static String CaseProcessing(String allocationUserName, String pol_Number, String ntuType, String medical_Charges, Logger log) throws Exception
	{
		String remark = "";
		String getPolNoFromIone = "";
		String getPolStatusFromIone = "";
		String caseAllocationRemark = "";
		String comboCaseError = "";

		try
		{
			log.info("--------------------------------------Inside Case CaseProcessing--------------------------------------------");
			webHandler.waitForPageLoad(80, log);
			
				
			caseAllocationRemark = CaseAllocationToUser(allocationUserName, pol_Number, log);//Calling function
			log.info("Case allocation remark inside case processing :" + caseAllocationRemark);

			webHandler.waitForPageLoad(80, log);

			if (caseAllocationRemark.equalsIgnoreCase("Policy Number and Status Found"))
			{
				Thread.sleep(2000);
				mouseMoveEventClick("//*[@id='mnuInsuranceOnen2']/table/tbody/tr/td[1]/a", "//*[@id='mnuInsuranceOnen9']/td/table/tbody/tr/td/a", log);//Click on Inbox
		
				Thread.sleep(5000);//Thread required

				webHandler.waitForPageLoad(80, log);

				log.info("Clicked on inbox button");
				
				

				webHandler.waitForID("ContentPlaceHolder1_txtThreadID", 8000);//Wait for ID

				webHandler.clearById("ContentPlaceHolder1_txtThreadID", 80);//Clear Text
				webHandler.sendById("ContentPlaceHolder1_txtThreadID", pol_Number, 40);//Enter Policy No

				webHandler.clickByXpath("//*[@id='ContentPlaceHolder1_searchWorksheet']", 60);//Click on Search
//				webHandler.clickByXpath("//*[@id='ContentPlaceHolder1_searchWorksheet']", 60);//Click on Search
				log.info("Clicked on search button");

				webHandler.waitForPageLoad(80, log);

				Thread.sleep(5000);
				List<WebElement> row = webHandler.getTableRowCount("ContentPlaceHolder1_grdWFBox", "tbody", "tr");//Get row Count
				log.info("Table Row size by getTableRowCount method :" + row.size());

				for(int i = 0; i < row.size(); i++) //previous it was i=2
				{
					Thread.sleep(3000);

					getPolStatusFromIone = "";	
					getPolNoFromIone = "";

					if (webHandler.checkXpath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr[" + i + "]/td[4]"))//Check Xpath
					{
						getPolNoFromIone = webHandler.getByxPath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr[" + i + "]/td[4]");//Get Policy No
						log.info("Policy No from Table :" + getPolNoFromIone);

						getPolStatusFromIone = webHandler.getByxPath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr[" + i + "]/td[7]");//Get status
						log.info("Policy Status from Table :" + getPolStatusFromIone);

						
						if ((getPolNoFromIone.equals(pol_Number)) && (getPolStatusFromIone.equalsIgnoreCase("NB NTU")))
						{
							log.info("Policy and Status are matched with input file details");
							log.info("Policy No from Ione table :" + getPolStatusFromIone);
							log.info("Policy Status from Ione table :" + getPolStatusFromIone);
							
							Thread.sleep(3000);

							parentWindow = VyomSeleniumHandler.driver.getWindowHandle();

							//Thread.sleep(3000);
							//System.out.println("------------1-------------");
							//Thread.sleep(3000);

							System.out.println("------------2-------------");

							//webHandler.waitForID("ContentPlaceHolder1_grdWFBox", 80);//Wait for ID
							
							//Need to check
							//webHandler.clickByXpath("//*[@id='ContentPlaceHolder1_searchWorksheet']", 60);//Click on Search
							//webHandler.clickByXpath("//*[@id='ContentPlaceHolder1_searchWorksheet']", 60);//Click on Search
							
						//	webHandler.clickByXpath("//*[@id='ContentPlaceHolder1_grdWFBox_chkbox_" + i + "']", 30);//Select Cases
						
						//	String dummy2 = webHandler.getByxPath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+i+"]/td[2]/a");//Get Policy No
							
					//		String dummy3 = webHandler.getByxPath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+i+"]/td[3]");//Get Policy No
						//	String dummy4 = webHandler.getByxPath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+i+"]/td[4]");//Get Policy No
							
							//i=i-2;
						//	System.out.println("dummy2 :"+ dummy2 +" "+ dummy3+" " +dummy4);
							
							webHandler.clickByXpath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+i+"]/td[2]/a", 20000);//Click on show (Error Steep By santosh check)

							Thread.sleep(15000);
							log.info("Clicked on show button for new window open");

							comboCaseError = webHandler.getByxPath("//*[@id='ContentPlaceHolder1_lblStatus']");//Get Combo Error
							log.info("Combo Case Error :"+comboCaseError);

							if(!comboCaseError.contains("Please Choose Combo Cases to complete"))//Combo error check
							{
								Assert.assertTrue(waitForNewWindow(15000, log), "New window is not opened after clicking on show button");//Verify new window is opened or not

								Set<String> handles = VyomSeleniumHandler.driver.getWindowHandles();
								Iterator<String> iterate = handles.iterator();//Iterator

								while(iterate.hasNext())
								{
									String newWinHandleIS = iterate.next().toString();
									if(!newWinHandleIS.contains(parentWindow))
									{
										log.info("Found new screen after clicking on show button :" + newWinHandleIS);
										VyomSeleniumHandler.driver.switchTo().window(newWinHandleIS);

										//web wait until by santosh
										
										//webHandler.waitForID("TabStrip1_Item2_TC", 60000);//Wait for ID
										
										webHandler.waitForPageLoad(400, log);
										VyomSeleniumHandler.driver.manage().window().maximize();//Maximize Window

										handleAlert_Dismiss(log);

										remark = workflowJobPanel_Processing(ntuType, medical_Charges, log);//Calling Function

										log.info("WorkflowJobPanel processing function remark :" + remark);
										VyomSeleniumHandler.driver.switchTo().window(parentWindow);
										webHandler.waitForPageLoad(400, log);
									}
								}
								break;
							}else
							{
								log.info("-----------------------Combo Case Error -------------------------- ");
								String getMPNFromIone = "";
								String[] getMpn = comboCaseError.split(":");
								String mpnNoIs = getMpn[1].trim();

								String comboPolicyNo = "";

								for(int j=2; j <= row.size(); j++)
								{			
									getMPNFromIone = "";
									getPolStatusFromIone = "";	
									getPolNoFromIone = "";

									if(webHandler.checkXpath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+j+"]/td[4]"))
									{
										getPolNoFromIone = webHandler.getByxPath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+j+"]/td[4]");//GetPolicy No
										log.info("Policy Number from Ione: "+getPolNoFromIone);

										getMPNFromIone = webHandler.getByxPath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+j+"]/td[18]");//Get MPN No
										log.info("MPN No from Ione :"+getMPNFromIone);

										getPolStatusFromIone = webHandler.getByxPath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+j+"]/td[7]");//get the status
										log.info("Policy Status from Ione :"+getPolStatusFromIone);

										if(mpnNoIs.equalsIgnoreCase(getMPNFromIone))
										{
											comboPolicyNo = getPolNoFromIone;
											log.info("Combo case policy found, policy no is :"+comboPolicyNo);

											remark = comboCaseError +" of policy number "+comboPolicyNo;
											log.info("Combo Error found :"+remark);
											break;
										}
									}//Check xpath

									if(j == row.size())
									{
										if(comboPolicyNo.equals(""))
										{
											remark = comboCaseError +", policy number not found against MNP number";
											log.info("Combo Error found policy no blank :"+remark);
										}else
										{
											remark = comboCaseError +" of policy number "+comboPolicyNo;
											log.info("Combo Error found :"+remark);
										}
									}
								}//End of for

								log.info("Combo Case Error loop completed :"+remark);
								break;
							}
						}else
						{
							remark = "Policy number and status not matched while case processing";
						}//Check status
					}
				}//End for
			}else
			{
				remark = caseAllocationRemark;
			}//Policy no and Status check
		}catch (Exception e)
		{
			remark = "Case Not processed in CaseProcessing Function/Ione Site Down";
			log.info("Error in inboxUserQueueProcessing function :" + e);

			boolean wincheckFlag = check_NewWindowPresent(log);
			log.info("Multiple window check flag :"+wincheckFlag);

			if(wincheckFlag)
			{
				VyomSeleniumHandler.driver.switchTo().window(parentWindow);
				log.info("Switch to default default window");
			}
		}
		return remark;
	}//End of CaseProcessing()

	public static String workflowJobPanel_Processing(String ntuType, String medical_Charges, Logger log) throws Exception
	{		
		String remark = "";
		String updateRemark = "";
		String suspenseError = "";

		try
		{
			log.info("------------------------------------Inside Workflow Job Panel Processing --------------------------------------");

			Thread.sleep(500);
			if(webHandler.checkId("splitPanePages"))
			{				
				webHandler.switchToFrame("splitPanePages");
				
				//webHandler.waitForID("TabStrip1_Item2_TC", 45000);//Wait for id

				if(VyomSeleniumHandler.driver.findElement(By.xpath("//*[@id='TabStrip1_Item2_TC']")).isDisplayed())//Check NTU Tab
				{
					webHandler.clickByJavaExecutorId("TabStrip1_Item2_TCnt", 90);//Click on NTU
					log.info("Clicked on NTU tab on workflow pannel");

					webHandler.waitForPageLoad(90, log);

					Thread.sleep(90);
					VyomSeleniumHandler.driver.switchTo().frame("iframe2");

					webHandler.waitForID("ddl_NTUTYPE_NPK_Str", 90);//Wait for id
					webHandler.selectDropDownByXpath("//*[@id='ddl_NTUTYPE_NPK_Str']", ntuType, 90);//Enter NTU type
					log.info("CaseType from input file is :"+ntuType);

					Thread.sleep(5000);
					webHandler.clickByXpath("//*[@id='txt_SuspenseBalance_NPK_Num']", 90);//Click on suspense amt

					webHandler.clearByXpath("//*[@id='txt_ReasonForNTU_NPK_Str']", 90);//Clear NTU type
					webHandler.sendByxpath("//*[@id='txt_ReasonForNTU_NPK_Str']", ntuType, 90);//Enter NTU type

					webHandler.clickByXpath("//*[@id='txt_SuspenseBalance_NPK_Num']", 90);//Click on suspense amt

					if(medical_Charges != "")
					{
						if(!VyomSeleniumHandler.driver.findElement(By.xpath("//*[@id='chk_DeductWaiver_NPK_Num']")).isSelected())
						{
							webHandler.clickById("chk_DeductWaiver_NPK_Num", 30);//Click on checkbox button
						}

						webHandler.clearByXpath("//*[@id='txt_MedicalCharges_NPK_Num']", 30);//Clear Description
						webHandler.sendByxpath("//*[@id='txt_MedicalCharges_NPK_Num']", medical_Charges, 30);//Enter medical_Charges
						webHandler.clickByXpath("//*[@id='txt_SuspenseBalance_NPK_Num']", 20);//Click on suspense amt
						log.info("Medical chanrges updated :"+medical_Charges);
					}else
					{
						log.info("Medical chanrges from input file is blank :"+ntuType);
					}

					webHandler.clearByXpath("//*[@id='txt_Remarks_NPK_Str']", 30);//Clear Remark
					webHandler.sendByxpath("//*[@id='txt_Remarks_NPK_Str']", ntuType, 30);//Enter Remark

					webHandler.clickByXpath("//*[@id='txt_SuspenseBalance_NPK_Num']", 20);//Click on suspense amt				

					webHandler.clearByXpath("//*[@id='txtMkl']", 30);//Clear MKL Comments
					webHandler.sendByxpath("//*[@id='txtMkl']", ntuType, 30);//Enter NTU type MKL Comments

					webHandler.clickByXpath("//*[@id='txt_SuspenseBalance_NPK_Num']", 20);//Click on suspense amt

					webHandler.clickByXpath("//*[@id='btn_Save']", 90);//Click on Save
					log.info("Clicked on save button, Information has updated as per input excel file details in Ione");

					webHandler.waitForPageLoad(90, log);
					Thread.sleep(4000);

					int loopSize = 40;
					for (int j = 0; j <= loopSize; j++)
					{
						updateRemark = "";
						suspenseError = "";		
						log.info("Inside path loop");						

						if(webHandler.checkXpath("//*[@id='TotalPAge10']/div/table[2]/tbody/tr/td/div/table/tbody/tr/td/span") || webHandler.checkXpath("//*[@id='TotalPAge10']/div/table[2]/tbody/tr/td/div/table/tbody/tr[2]/td/span"))
						{
							suspenseError = webHandler.getByxPath("//*[@id='TotalPAge10']/div/table[2]/tbody/tr/td/div/table/tbody/tr/td/span");//Error Remark check
							log.info("Suspense/Refund Error :"+suspenseError);

							updateRemark = webHandler.getByxPath("//*[@id='TotalPAge10']/div/table[2]/tbody/tr/td/div/table/tbody/tr[2]/td/span");//Update Remark check
							log.info("Update status remark :"+updateRemark);

							if (updateRemark.equalsIgnoreCase("Updated Sucessfully"))
							{
								log.info("Details updated in Ione remark :" + updateRemark);
								remark = esbProcessing(ntuType, log);//Calling Function 
								break;
							}else
							{
								log.info("Inside else part");

								if(!suspenseError.equalsIgnoreCase(""))
								{
									remark = suspenseError;
									webHandler.closeDriver();
									log.info("Refund/Suspense error found break done :" + suspenseError);
									break;
								}else
								{
									log.info("Inside suspense update remark, remark is blank :"+suspenseError);
									Thread.sleep(1500);
								}
							}
						}else
						{
							log.info("Waiting for suspense error/update remark xpath");
							Thread.sleep(1000);							
						}
						if(j==loopSize)
						{
							remark = "Timeout for getting Life Asia update remark, case not processed";
						}
					}//End For
				}else
				{
					remark = "NTU Tab Not Available In Workflow Panel";
					webHandler.closeDriver();
				}//Check NTU TAB
			}else
			{
				boolean wincheckFlag = check_NewWindowPresent(log);
				log.info("Win check Flag :"+wincheckFlag);

				log.info("After click on show, required page content not open");
				remark = "Ione Site Is Down, Due to Server Error Found";
			}
		}catch (Exception e)
		{
			remark = "Case Not Processed in Workflow Job Pannel/Ione Site Down";
			log.info("Error in workflow job panel processing :" + e);

			boolean wincheckFlag = check_NewWindowPresent(log);
			log.info("Win check Flag :"+wincheckFlag);
		}
		return remark;
	}//End of WorkjobPannel Processing

	public static String esbProcessing(String caseType, Logger log) throws Exception
	{
		String remark = "";
		String selectOptionRemark = "";
		boolean pannelCheckFlag = false;
		boolean noError_Detected_Check = false;
		String getLARemark = "";

		try
		{
			log.info("------------------------------------------Inside ESB Processing---------------------------------------------");

			Thread.sleep(500);
			webHandler.switchToFrame("splitPanePages");

			try
			{
				webHandler.clickByJavaExecutorXpath("//*[@id='TabStrip1_Item3_TC']", 30);//Enter on ESB TAB
				log.info("In try - Clicked on ESB tab on workflow pannel");
			}catch(Exception e)
			{
				webHandler.clickByXpath("//*[@id='TabStrip1_Item3_TC']", 5);//Enter on ESB TAB
				log.info("in catch- Clicked on ESB tab on workflow pannel");
			}

			Thread.sleep(1000);
			VyomSeleniumHandler.driver.switchTo().frame("iframe3");

			try
			{
				webHandler.clickByJavaExecutorXpath("//*[@id='btn_submit']", 50);//Click on LA Submit
				log.info("In try- Clicked on LA button for updating remark in life Asia");	
			}catch(Exception e)
			{
				webHandler.clickByXpath("//*[@id='btn_submit']", 5);//Click on LA Submit
				log.info("In catch- Clicked on LA button for updating remark in life Asia");	
			}//Sometimes click not done

			webHandler.waitForPageLoad(40, log);
			log.info("Clicked on LA button for updating remark in life Asia");			

			Thread.sleep(2000);

			for(int c = 0; c <= 90; c++)
			{
				getLARemark = "";
				if(webHandler.checkXpath("//*[@id='GridBOLogDetails']/tbody/tr[2]/td[6]"))
				{
					getLARemark = webHandler.getByxPath("//*[@id='GridBOLogDetails']/tbody/tr[2]/td[6]");//Get LA remark
					log.info("Get Life Asia Remark :" + getLARemark);

					if(getLARemark.equalsIgnoreCase("No errors detected"))
					{
						noError_Detected_Check = true;
						break;
					}else
					{
						log.info("Waiting for Life Asia Remark...");
						Thread.sleep(1000);
					}
				}else
				{
					log.info("Waiting for Life Asia Remark xpath");
					Thread.sleep(1000);
				}
			}

			log.info("No Error detected flag is:" + noError_Detected_Check);

			if(noError_Detected_Check)
			{
				VyomSeleniumHandler.driver.switchTo().defaultContent();
				for (int j = 0; j <= 5; j++) 
				{
					try
					{
						Thread.sleep(5000);
						webHandler.clickByJavaExecutorXpath("//*[@id='SlidingPane1_item']/tbody/tr/td/span", 90);//Pannel
						Thread.sleep(2000);
						webHandler.clickByXpath("//*[@id='SlidingPane1_DockImg']", 200);//Click on freez
						Thread.sleep(Integer.parseInt(VyomSeleniumHandler.getProperties("PannelFreezWaitInMSecond")));//pannel Frez wait
						log.info("Workflow pannel opened");
						pannelCheckFlag = true;
						break;
					}catch (Exception e)
					{
						Thread.sleep(1000);
						pannelCheckFlag = false;
						log.info("Workflow pannel not open");
					}
				}//End of For

				log.info("Pannel open check flag :" +pannelCheckFlag);

				if (pannelCheckFlag)
				{
					webHandler.waitForPageLoad(60, log);
					Thread.sleep(1000);

					webHandler.waitForID("iframe1", 30);//Wait for ID
					if(webHandler.checkId("iframe1"))//Check ID
					{										
						for(int k=0;k<=Integer.parseInt(VyomSeleniumHandler.getProperties("PannelLoadWaitLoopCount"));k++)
						{
							webHandler.switchToFrame("iframe1");
							log.info("iframe1 id found frame switched");

							if(webHandler.checkXpath("//*[@id='TabStrip1_Item2_TCnt']"))
							{
								log.info("Panel loaded, break loop");
								break;
							}else
							{
								Thread.sleep(1000);
								log.info("Wating for panel load...");
							}
						}

						if(webHandler.checkXpath("//*[@id='TabStrip1_Item2_TCnt']"))//Check Note ID
						{
							webHandler.clickByXpath("//*[@id='TabStrip1_Item2_TCnt']", 60);//Click on notes
							log.info("Clicked on notes tab");
							Thread.sleep(500);

							webHandler.sendByxpath("//*[@id='RichTextEditor1_Center']", caseType+" ", 30);//Enter Client NTU
							log.info("Case type updated in Ione as :"+caseType);
							Thread.sleep(1000);

							webHandler.clickByXpath("//*[@id='TabStrip1_Item1_TCnt']", 30);//Click on Job Commands
							log.info("Clicked on JobCommands tab");

							selectOptionRemark = webHandler.getDropDownBoxValueByName("ddlPhases", "NB Refund", log);//Get option
							log.info("NB Refund option check in dropdown :" + selectOptionRemark);

							if (selectOptionRemark.equalsIgnoreCase("Option Name Found"))
							{
								webHandler.selectDropDownByName("ddlPhases", "NB Refund", 30);//Select Option
								log.info("NB Refund option selected");
								Thread.sleep(2000);

								if (VyomSeleniumHandler.driver.findElement(By.xpath("//*[@id='btnJobDone']")).isEnabled())//Check button enabled
								{
									log.info("------------------------------------Normal Case Processing-----------------------------------------");

									webHandler.clickByXpath("//*[@id='btnJobDone']", 30);//Click on Submit
									log.info("Clicked on Job Done for further processing and waiting for new window occure");
									Thread.sleep(2000);

									Assert.assertTrue(waitForNewWindow(50, log), "New window is not opened after clicking on JobDone in normal flow");//Verify new window is opened or not

									Set<String> handles = VyomSeleniumHandler.driver.getWindowHandles();
									int screenSizeIs = handles.size();
									log.info("Screen size :"+screenSizeIs);

									if(screenSizeIs > 1)
									{
										Iterator<String> iterate = handles.iterator();//Iterator

										while(iterate.hasNext())
										{
											String newWinHandle = iterate.next().toString();
											if(!newWinHandle.contains(parentWindow))
											{
												log.info("Found new screen while normal flow processing:" + newWinHandle);
												VyomSeleniumHandler.driver.switchTo().window(newWinHandle);
												VyomSeleniumHandler.driver.close();
												remark = "Case Processed Successfully";
											}
										}	
									}else
									{
										remark = "Case Not Processed due to JobDone screen not open in normal flow";
										VyomSeleniumHandler.driver.close();										
									}
								}else if(webHandler.checkXpath("//*[@id='P_Ctrl_Status1_Panel1']/table/tbody/tr[1]/td"))//Check Xpath 
								{
									log.info("---------------------------------Combo Case Processing-------------------------------------------");

									String comboErrorRemark = webHandler.getByxPath("//*[@id='P_Ctrl_Status1_Panel1']/table/tbody/tr[1]/td");//Get Combo Error
									log.info("Combo case error in job command next phase :" + comboErrorRemark);

									if (comboErrorRemark.equals("Combo Case, all proposals not completed this phase,Please choose \"NB NTU Combo\" Decision"))//Check Error
									{
										selectOptionRemark = "";
										selectOptionRemark = webHandler.getDropDownBoxValueByName("ddlPhases", "NB NTU Combo", log);//Check Tab present
										log.info("NB NTU Combo option check in dropdown :" + selectOptionRemark);
										if (selectOptionRemark.equalsIgnoreCase("Option Name Found"))
										{
											webHandler.selectDropDownByName("ddlPhases", "NB NTU Combo", 30);//Select NB NTU Combo
											log.info("NB NTU Combo option selected");
											Thread.sleep(1500);

											webHandler.clickByXpath("//*[@id='btnJobDone']", 30);//Click on Submit
											log.info("Clicked on JobDone button in combo case processing");
											Thread.sleep(2000);

											Set<String> handles = VyomSeleniumHandler.driver.getWindowHandles();
											int sizeIs = handles.size();
											log.info("Combo case screen size :"+sizeIs);

											if(sizeIs > 1)
											{
												Iterator<String> iterate = handles.iterator();//Iterator

												while(iterate.hasNext())
												{
													String newWinHandle = iterate.next().toString();
													if(!newWinHandle.contains(parentWindow))
													{
														log.info("Found new screen in combo case processing flow :" + newWinHandle);
														VyomSeleniumHandler.driver.switchTo().window(newWinHandle);
														VyomSeleniumHandler.driver.close();
														remark = "Error in combo case processing";
													}
												}
											}else
											{
												remark = "Case Processed Successfully";
												log.info("Combo Case Processed Successfully");////Need to check
											}
										}else
										{
											remark = "NB NTU Combo "+ selectOptionRemark;
											VyomSeleniumHandler.driver.close();
										}//Option Check
									}else
									{
										remark = "NB NTU Combo :"+comboErrorRemark;
										VyomSeleniumHandler.driver.close();
									}//Combo check
								}else
								{
									remark = "NB Refund :" + selectOptionRemark;
									VyomSeleniumHandler.driver.close();
								}//End of check button
							}else
							{
								remark = "NB Refund :" + selectOptionRemark;
								VyomSeleniumHandler.driver.close();
							}
						}else
						{
							remark = "Ione Site Is Down, Due to Server Error Found";
							VyomSeleniumHandler.driver.close();
						}//Pannel Opn Check
					}else
					{
						remark = "Ione Site Is Down, Due to Server Error Found";
						VyomSeleniumHandler.driver.close();
					}//Pannel Opn Check
				}else
				{
					remark = "WorkFlow Pannel Not Open/Site Down";
					VyomSeleniumHandler.driver.close();
				}
			}else
			{
				log.info("No error detected remark not found, Life asia submit remark is blank");
				remark = "Life Asia Submit Remark Is Blank/Other error occured";
				VyomSeleniumHandler.driver.close();
			}//End of No errors detected
		}catch (Exception e)
		{
			remark = "Case Not Processed In ESB Processing/Ione Site Down";
			log.info("Error in esbProcessing function :" + e);

			boolean wincheckFlag = check_NewWindowPresent(log);
			log.info("Win check flag is :"+wincheckFlag);
		}
		return remark;
	}//End of ESB Processing 

	public static boolean check_NewWindowPresent(Logger log)
	{
		boolean winCheckFlag = false;
		int sizeIs = 0;

		try
		{		
			log.info("---------------------------------------------Inside New Win Check-------------------------------------------------");

			Set<String> handles = VyomSeleniumHandler.driver.getWindowHandles();
			sizeIs = handles.size();
			log.info("Screen len in checkWinPresent :"+sizeIs);

			if(sizeIs > 1)
			{
				Iterator<String> iterate = handles.iterator();//Iterator

				while(iterate.hasNext())
				{
					String newWinHandle = iterate.next().toString();
					if(!newWinHandle.contains(parentWindow))
					{
						log.info("Found new in window :" + newWinHandle);
						VyomSeleniumHandler.driver.switchTo().window(newWinHandle);
						VyomSeleniumHandler.driver.close();
						log.info("New window closed");
						winCheckFlag = true;
					}
				}	
			}else
			{
				log.info("While processing new screen not found :"+sizeIs);
			}
		}catch(Exception e)
		{
			log.info("Error in check_NewWindowPresent :"+e);
		}
		return winCheckFlag;
	}//End of checkWinPresent()

	public static boolean waitForNewWindow(int timeout, Logger log)
	{
		log.info("-------------------------------Inside Wait For New Window-----------------------------------------");

		boolean flag = false;
		int counter = 0;
		while(!flag)
		{
			try 
			{
				Set<String> winId = VyomSeleniumHandler.driver.getWindowHandles();
				if(winId.size() > 1)
				{
					log.info("New Window found :"+winId);
					flag = true;
					return flag;
				}
				Thread.sleep(2000);
				counter++;
				if(counter > timeout)
				{
					return flag;
				}
			} catch (Exception e) 
			{
				log.info("Error in waitForNewWindow: "+e);
				return false;
			}
		}
		return flag;
	}//End of waitForNewWindow

	public static boolean mouseMoveEventClick(String mainElementXpath, String moveToElementXpath, Logger log)
	{
		boolean mouseClickEvent = false;
		try
		{
			Actions action = new Actions(VyomSeleniumHandler.driver);
			WebElement we = VyomSeleniumHandler.driver.findElement(By.xpath(mainElementXpath));
			action.moveToElement(we).moveToElement(VyomSeleniumHandler.driver.findElement(By.xpath(moveToElementXpath))).click().build().perform();
			mouseClickEvent = true;

			webHandler.waitForPageLoad(50, log);
			Thread.sleep(2000);
		}
		catch (Exception e)
		{
			log.info("Error in Mouse Move Clicking :" + e);
			mouseClickEvent = false;
		}
		return mouseClickEvent;
	}

	public static void handleAlert_Dismiss(Logger log)
	{
		if(isAlertPresent()){
			Alert alert = VyomSeleniumHandler.driver.switchTo().alert();
			log.info("Alert Is :"+alert.getText());
			alert.dismiss();
		}else
		{
			log.info("Alert not present");
		}
	}//End of handleAlert

	public static boolean isAlertPresent()
	{
		try{
			VyomSeleniumHandler.driver.switchTo().alert();
			return true;

		}catch(NoAlertPresentException ex)
		{
			return false;
		}
	}//End of isAlertPresent

	public static void logOut(Logger log) throws Exception
	{
		try
		{
			webHandler.clickById("lnkLogin", 30);
			Thread.sleep(500);
			log.info("Log Out");
			webHandler.clearDriverInstances();
		}catch (Exception e)
		{
			log.info("Error in logOut :" + e);
		}
	}//End of Logout

	public static void textFileRemarkWrite(String remark, Logger log) throws Exception
	{
		if(!remark.equals(""))
		{
			File fileIs = new File(VyomSeleniumHandler.getProperties("RemarkTXTFile"));
			if(fileIs.createNewFile())
			{
				log.info("TXT File is created");
				Thread.sleep(1000);
			}

			FileOutputStream out = new FileOutputStream(VyomSeleniumHandler.getProperties("RemarkTXTFile")); 
			try
			{
				out.flush();
				out.write(remark.getBytes());//out.write(remark.getBytes(),0,remark.length());
				out.close();
				log.info("TXT File Writting done :"+remark);

			}catch(Exception e)
			{
				log.info("Error in TXT file writting :"+e);
			}
		}else
		{
			log.info("While file writting remark was Blank");
		}
	}//End of textFileRemarkWrite()
}
