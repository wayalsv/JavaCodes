package kli.org.ione.pr01;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.automationedge.ps.core.util.Assert;

import all.org.vyomlibrary.VyomSeleniumHandler;

/**
 * 
 * @author Sachin M LO5015
 **
 */

public class PRS_IOne
{
	static VyomSeleniumHandler webHandler = new VyomSeleniumHandler();
	static boolean allocationRetry = true;

	public static String login(String username, String password, Logger log) throws Exception
	{
		String remark = "";
		String errorRemark = "";
		try
		{
			log.info("------------------------------------------Inside login------------------------------------------------- ");

			log.info("Url Change Flag :"+PRS_Checker_Main.urlChange);

			if(PRS_Checker_Main.urlChange)
			{
				webHandler.loadUrl(VyomSeleniumHandler.getProperties("Ione_URL_Beta"));//Enter URL
				log.info("Url Is : Ione Beta :"+VyomSeleniumHandler.getProperties("Ione_URL_Beta"));
			}else
			{
				webHandler.loadUrl(VyomSeleniumHandler.getProperties("Ione_URL_CPC"));//Enter URL
				log.info("Url Is : Ione CPC :"+VyomSeleniumHandler.getProperties("Ione_URL_CPC"));
			}

			webHandler.sendById("ContentPlaceHolder1_txtUserName", username, 30);//Enter Username
			webHandler.sendById("ContentPlaceHolder1_txtPassword", password, 30);//Enter Password

			webHandler.clickById("ContentPlaceHolder1_btnLogin", 30);//Click on login button

			webHandler.waitForPageLoad(55, log);//Waiting for page load

			Thread.sleep(2000);

			errorRemark = webHandler.getByXpath("//*[@id='ContentPlaceHolder1_P_Ctrl_Status1_lblErrMsg']", 30);//Get Remark
			if(!errorRemark.equals(""))
			{
				remark = errorRemark;
			}else
			{
				remark = "Login Successfully";
			}

		}catch(Exception e)
		{
			PRS_Checker_Main.urlChange = true;
			log.info("Error in i_One_Portal Login :"+e);
			throw e;
		}//End of Try

		return remark;

	}//End of i_One_Login()

	public static String CasesAllocation(Logger log) throws Exception
	{
		String remark = "";
		try
		{	
			log.info("----------------------------------------Inside CasesAllocation--------------------------------------------");

			mouseMoveEventClick("//*[@id='mnuInsuranceOnen2']/table/tbody/tr/td[1]/a", "//*[@id='mnuInsuranceOnen13']/td/table/tbody/tr/td/a", log);//Click on My Home
			webHandler.waitForPageLoad(55, log);//Waiting for page load

			webHandler.clickByXpath("//*[@id='ContentPlaceHolder1_TabStrip1_Item3_TCnt']", 30);//Click on Users Status
			webHandler.waitForPageLoad(50, log);//Waiting for page load

			webHandler.waitForID("ContentPlaceHolder1_ddlBucketType", 30);//Wait for name

			WebElement dropdown = VyomSeleniumHandler.driver.findElement(By.id("ContentPlaceHolder1_ddlBucketType"));
			Select select = new Select(dropdown);
			List<WebElement> options = select.getOptions();

			int n = 1;
			for (WebElement we : options)
			{
				String getOption = we.getText().trim();

				if(getOption.equalsIgnoreCase("NB PRS Checker"))
				{
					remark = "Queue Name Found";
					log.info("Queue Name Found, Status Type: " + n + ": " + getOption);//Status Type
					select.selectByVisibleText(getOption);//Select option
					webHandler.clickByName("ctl00$ContentPlaceHolder1$Btnsearch", 30);//Click on Show	
					break;
				}else
				{
					remark = "NB PRS Checker Queue Is Empty or Bucket Not Found";
				}
				n++;
			}
		}catch(Exception e)
		{
			remark = "Error in CasesAllocation";
			log.info("Error in CasesAllocation :"+e);
			throw e;
		}
		return remark;
	}//End of CasesAllocation()

	public static boolean allocatedCasesChecker(Logger log) throws Exception
	{
		boolean allocatedCaseRemark = false;
		String policyNoFromIone = "";
		String statusFromIone = "";

		log.info("---------------------------------------------Inside Allocated Cases Checker--------------------------------------");

		try
		{
			webHandler.waitForPageLoad(50, log);//Wait for page load 
			mouseMoveEventClick("//*[@id='mnuInsuranceOnen2']/table/tbody/tr/td[1]/a", "//*[@id='mnuInsuranceOnen9']/td/table/tbody/tr/td/a", log);//Click on Inbox
			webHandler.waitForPageLoad(50, log);//Wait for page load 

			Thread.sleep(2500);
			List<WebElement> rowIs = webHandler.getTableRowCount("ContentPlaceHolder1_grdWFBox", "tbody", "tr");//Get table row Size				
			log.info("Table Row size inside allocatedCasesChecker :"+rowIs.size());

			if(rowIs.size() > 1)
			{
				for(int i=2; i < rowIs.size(); i++)
				{									
					if(webHandler.checkXpath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+i+"]/td[7]"))
					{
						policyNoFromIone = webHandler.getByxPath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+i+"]/td[4]");//GetPolicy No
						log.info("Policy Number from Ione: "+policyNoFromIone);

						statusFromIone = webHandler.getByxPath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+i+"]/td[7]");//get the status
						log.info("Policy Status From Ione :"+statusFromIone);

						if(statusFromIone.equalsIgnoreCase("NB PRS Checker"))
						{
							allocatedCaseRemark = true;
							log.info("Allready allocated case found");
							break;
						}
					}
				}
			}
		}catch(Exception e)
		{
			log.info("Error in allocatedCasesChecker :"+e);
			throw e;
		}
		return allocatedCaseRemark;
	}//End of allocatedCasesChecker

	public static String tsarBandQueueProcessing(String allocationUserName,Logger log) throws Exception
	{
		String remark = "";
		String queueSelectionRemark = "";
		boolean queueCheckerFlag = false;
		int pendingCountCheck = 0;
		int alreadyCasesCheck = 3;

		log.info("----------------------------------------Inside TSARBandQueueProcessing---------------------------------------");		
		try
		{
			if(allocationRetry)
			{
				for(int j=1;j<=alreadyCasesCheck;j++)//check if cases are already present in queue
				{
					webHandler.waitForPageLoad(50, log);//Wait for page load
					queueCheckerFlag = allocatedCasesChecker(log);//Calling function
					log.info("Already cases allocated flag :"+queueCheckerFlag);

					if(queueCheckerFlag)
					{
						remark = inboxUserQueueProcessing(allocationUserName, log);// Calling function	
						log.info("Inbox User Queue Processing Remark for already aloocated cases: "+remark);
						log.info("Cases processed from already allocated queue");
					}else
					{
						log.info(":------------Already allocated Cases are not present in queue, loop count :"+j+"-----------:");
					}//queueCheckerFlag

					if(j==alreadyCasesCheck)
					{
						allocationRetry = false;
					}
				}

			}

			for(int k=2; k<=15; k++)//Statically define the queue size
			{
				webHandler.waitForPageLoad(50, log);//Wait for page load

				queueSelectionRemark =  PRS_IOne.CasesAllocation(log);//Calling function
				log.info("NB_PRS_QueueSelection Remark Is :"+queueSelectionRemark);

				webHandler.waitForPageLoad(50, log);//wait for page load

				if(queueSelectionRemark.equalsIgnoreCase("Queue Name Found"))
				{
					Thread.sleep(700);
					if(webHandler.checkXpath("//*[@id='ContentPlaceHolder1_GrdPhaseWise']/tbody/tr["+k+"]/td[1]/a"))//Check first Queue present	
					{
						webHandler.clickByXpath("//*[@id='ContentPlaceHolder1_GrdPhaseWise']/tbody/tr["+k+"]/td[1]/a", 30);//Click on first Queue
						webHandler.waitForPageLoad(50, log);//Wait for load

						webHandler.clickByXpath("//*[@id='ContentPlaceHolder1_G_Ctrl_Allocation1_grdWFBox_chkboxHdr']", 30);//Select All cases
						webHandler.selectDropDownById("ContentPlaceHolder1_G_Ctrl_Allocation1_ddlUsers", allocationUserName, 30);//Allocation User

						Thread.sleep(500);
						mouseMoveEventClick("//*[@id='ContentPlaceHolder1_G_Ctrl_Allocation1_mnuWFn0']/table/tbody/tr/td[1]", "//*[@id='ContentPlaceHolder1_G_Ctrl_Allocation1_mnuWFn1']/td/table/tbody/tr/td/a", log);//Mouse Move Click
						log.info("Case Allocated to "+allocationUserName);

						webHandler.waitForPageLoad(50, log);//Wait for page loading

						remark = inboxUserQueueProcessing(allocationUserName, log);// Calling function

						log.info("Inbox User Queue Processing Remark: "+remark);
						log.info(" :-------------------------------------"+ k +"-----------------------------------------: ");

					}else
					{
						if(pendingCountCheck != 3)
						{
							pendingCountCheck = pendingCountCheck + 1;
							log.info("PendingCountCheck flag count :"+pendingCountCheck);

							String pendingCountFromIone = webHandler.getByxPath("//*[@id='ContentPlaceHolder1_lblTotalCases']");//Get Pending count
							log.info("Pending count from Ione :"+pendingCountFromIone);

							if(Integer.parseInt(pendingCountFromIone) > 0)
							{
								k = 1;//Queue is cleared after processing
								log.info("Pending cases are present, K value change to 1 :"+pendingCountFromIone);
							}
						}else
						{
							remark = "TSAR Queue is Empty";
							break;
						}

					}
				}else
				{
					remark = queueSelectionRemark;
					log.info("Queue Selection Remark :"+queueSelectionRemark);
					break;
				}
			}//For
		}catch(Exception e)
		{
			remark = "Error in TSAR Band Queue Processing";
			log.info("Error in TSAR Band Queue Processing :"+e);
			throw e;
		}
		return remark;

	}//End of caseProcessing()

	public static String inboxUserQueueProcessing(String inboxUserName, Logger log) throws Exception
	{
		String remark = "";
		String statusFromIone = "";
		String comboCaseError = "";
		String policyNoFromIone = "";
		boolean comboCaseFlag = false;

		log.info("------------------------------------Inside inboxUserQueueProcessing-----------------------------------------");
		try
		{
			mouseMoveEventClick("//*[@id='mnuInsuranceOnen2']/table/tbody/tr/td[1]/a", "//*[@id='mnuInsuranceOnen9']/td/table/tbody/tr/td/a", log);//Click on Inbox

			webHandler.waitForPageLoad(50, log);//Wait for page
			webHandler.selectDropDownByName("ctl00$ContentPlaceHolder1$ddlUsers", inboxUserName, 30);//Inbox User
			webHandler.waitForPageLoad(50, log);//Wait for page

			Thread.sleep(2500);
			List<WebElement> rowIs = webHandler.getTableRowCount("ContentPlaceHolder1_grdWFBox", "tbody", "tr");//Get table row Size				
			log.info("Table Row size :"+rowIs.size());

			String parentWindow = VyomSeleniumHandler.driver.getWindowHandle();

			if(rowIs.size() > 1)
			{
				for(int i=2; i < rowIs.size(); i++)
				{									
					if(webHandler.checkXpath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+i+"]/td[7]"))
					{
						statusFromIone = "";
						comboCaseError = "";

						policyNoFromIone = webHandler.getByxPath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+i+"]/td[4]");//GetPolicy No
						log.info("Policy Number from Ione: "+policyNoFromIone);

						statusFromIone = webHandler.getByxPath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+i+"]/td[7]");//get the status
						log.info("Policy Status from Ione: "+statusFromIone);

						if(statusFromIone.equalsIgnoreCase("NB PRS Checker"))
						{
							webHandler.clickByXpath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+i+"]/td[2]/a", 30000);//Click on show
							Thread.sleep(2500);

							comboCaseError = webHandler.getByxPath("//*[@id='ContentPlaceHolder1_lblStatus']");//Get Combo Error
							log.info("Combo Case Error :"+comboCaseError);

							if(!comboCaseError.contains("Please Choose Combo Cases to complete"))//Combo error check
							{
								log.info("Policy Number from Ione: "+policyNoFromIone);
								log.info("Policy Status from Ione :"+statusFromIone);

								Assert.assertTrue(waitForNewWindow(30, log), "New window is not opened after clicking on show");//Verify new window is opened or not

								Set<String> handles = VyomSeleniumHandler.driver.getWindowHandles();
								Iterator<String> iterate = handles.iterator();//Iterator

								while(iterate.hasNext())
								{
									String newWinHandleIS = iterate.next().toString();
									if(!newWinHandleIS.contains(parentWindow))
									{
										log.info("Found new screen after clicking on show :" + newWinHandleIS);
										VyomSeleniumHandler.driver.switchTo().window(newWinHandleIS);

										webHandler.waitForPageLoad(50, log);//Wait for page load 
										VyomSeleniumHandler.driver.manage().window().maximize();

										remark = workflowJobPanel_Processing(log);//Calling function										
										log.info("workflowJobPanel_Processing :"+remark);
										Thread.sleep(2000);

										VyomSeleniumHandler.driver.switchTo().window(parentWindow); //cntrl transfer to parent window
										VyomSeleniumHandler.driver.navigate().refresh();//Refreshing the page

										webHandler.waitForPageLoad(50, log);//Wait for page load 
										Thread.sleep(2000);
									}//windowHandleout
								}//windowHandle
							}else
							{
								log.info("-----------------------Combo Case Error Processing-------------------------- ");
								String getMPNFromIone = "";
								String[] getMpn = comboCaseError.split(":");
								String mpnNoIs = getMpn[1].trim();

								String comboPolicy = "";

								for(int j=2; j <= rowIs.size(); j++)
								{			
									getMPNFromIone = "";
									statusFromIone = "";	
									policyNoFromIone = "";

									if(webHandler.checkXpath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+j+"]/td[4]"))
									{
										policyNoFromIone = webHandler.getByxPath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+j+"]/td[4]");//GetPolicy No
										log.info("Policy Number from Ione: "+policyNoFromIone);

										getMPNFromIone = webHandler.getByxPath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+j+"]/td[18]");//Get MPN No
										log.info("MPN No from Ione :"+getMPNFromIone);

										statusFromIone = webHandler.getByxPath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+j+"]/td[7]");//get the status
										log.info("Policy Status from Ione :"+statusFromIone);

										if(mpnNoIs.equalsIgnoreCase(getMPNFromIone) && comboCaseFlag == false)
										{
											comboCaseFlag = true;
											comboPolicy = policyNoFromIone;
											log.info("Combo case policy found :"+comboPolicy);
										}

										if(getMPNFromIone.equals(mpnNoIs.trim()) && statusFromIone.equalsIgnoreCase("NB PRS Checker"))
										{
											log.info("MPN and Status are matched");
											log.info("Policy Number from Ione: "+policyNoFromIone);
											log.info("MPN No from Ione :"+getMPNFromIone);
											log.info("Policy Status from Ione :"+statusFromIone);

											webHandler.clickByXpath("//*[@id='ContentPlaceHolder1_grdWFBox']/tbody/tr["+j+"]/td[2]/a", 30);//Click on show
											Thread.sleep(2500);

											Assert.assertTrue(waitForNewWindow(30, log), "New window is not opened after clicking on show");//Verify new window is opened or not

											Set<String> handles = VyomSeleniumHandler.driver.getWindowHandles();
											Iterator<String> iterate = handles.iterator();//Iterator

											while(iterate.hasNext())
											{
												String newWinHandleIS = iterate.next().toString();
												if(!newWinHandleIS.contains(parentWindow))
												{
													log.info("Found new screen after clicking on show :" + newWinHandleIS);
													VyomSeleniumHandler.driver.switchTo().window(newWinHandleIS);

													webHandler.waitForPageLoad(50, log);//Wait for page load 
													VyomSeleniumHandler.driver.manage().window().maximize();

													remark = workflowJobPanel_Processing(log);//Calling function
													log.info("workflowJobPanel_Processing after combo error occured :"+remark);
													log.info("Combo case processed :"+comboCaseError);
													Thread.sleep(2000);

													VyomSeleniumHandler.driver.switchTo().window(parentWindow); //cntrl transfer to parent window
													VyomSeleniumHandler.driver.navigate().refresh();//Refreshing the page

													webHandler.waitForPageLoad(50, log);//Wait for page load 
													Thread.sleep(2000);

												}//windowHandle
											}//windowHandle
											break;
										}//Check status and MNP
									}//Check xpath

									if(j == rowIs.size())
									{
										if(comboPolicy.equals(""))
										{
											remark = comboCaseError +", policy number not found against MNP number.";
											log.info("Combo Error found policy no blank :"+remark);
										}else
										{
											remark = comboCaseError +" of policy number "+comboPolicy+".";
											log.info("Combo Error found :"+remark);
										}

										PRS_IOne.textFileRemarkWrite(remark, log);
										log.info("Process Terminated due to :"+comboCaseError);
										webHandler.clearDriverInstances();
										System.exit(-1);
									}
								}
							}//End else
						}else
						{
							remark = "NB PRS Checker status not found while processing";
							log.info("Case has different Status :"+statusFromIone);
						}//End of status check
					}
				}//End of Table Size()
			}else
			{
				remark = "No Records Available";
			}
		}catch(Exception e)
		{
			log.info("Error in inboxUserQueueProcessing :"+e);
			remark = "Error in inboxUserQueueProcessing";
			throw e;
		}
		return remark;
	}//End of caseChecker()

	public static Date yesterday() 
	{
		final Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		return cal.getTime();
	}//End of yesterday()

	public static String workflowJobPanel_Processing(Logger log) throws Exception
	{
		String remark = "";
		String getLastNBPrsComment = "";
		String checkDropDownValue = "";
		String secondLineCmt = "";
		int commentCount = 0;
		boolean pannelCheck = false;

		log.info("------------------------------------Inside workflowJobPanel Processing------------------------------------");

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String todaysDate = sdf.format(new Date());
		log.info("Todays Date :"+todaysDate);

		try
		{		
			for(int j=0; j<=3; j++)
			{
				try
				{
					Thread.sleep(500);
					if(webHandler.checkXpath("//*[@id='SlidingPane1_item']/tbody/tr/td/span"))//Check Xpath present
					{
						webHandler.clickByJavaExecutorXpath("//*[@id='SlidingPane1_item']/tbody/tr/td/span", 30);//Click on workflow pannel
						Thread.sleep(1500);
						webHandler.clickByXpath("//*[@id='SlidingPane1_DockImg']", 50);//Pannel freez						
						Thread.sleep(Integer.parseInt(VyomSeleniumHandler.getProperties("PannelFreezWaitInMSecond")));//pannel Frez wait		

						pannelCheck = true;
						log.info("Pannel Open");
						break;
					}else
					{
						pannelCheck = false;
						log.info("Login to insurance I-One error screen found");
					}
				}catch(Exception e)
				{
					Thread.sleep(1000);
					pannelCheck = false;
					log.info("Pannel Not Open :"+e);
				}
			}			

			if(pannelCheck)
			{
				Thread.sleep(1000);
				webHandler.waitForPageLoad(50, log);

				webHandler.waitForID("iframe1", 30);//Wait for ID
				if(webHandler.checkId("iframe1"))
				{											
					for(int k=0;k<=Integer.parseInt(VyomSeleniumHandler.getProperties("PannelLoadWaitLoopCount"));k++)
					{
						webHandler.switchToFrame("iframe1");
						log.info("iframe1 id found frame switched");
						
						if(webHandler.checkXpath("//*[@id='TabStrip1_Item3_TCnt']"))
						{
							log.info("Panel loaded, break loop");
							break;
						}else
						{
							Thread.sleep(1000);
							log.info("Wating for panel load...");
						}
					}

					if(webHandler.checkXpath("//*[@id='TabStrip1_Item3_TCnt']"))//Check Note histroy 
					{						
						webHandler.clickByXpath("//*[@id='TabStrip1_Item3_TCnt']", 30);//Note History
						log.info("Clicked On Note histroy Tab");

						Thread.sleep(2000);						
						for(int i=1; i<150;i++)
						{
							if(webHandler.checkXpath("//*[@id='dtlstThreadNotes']/tbody/tr["+i+"]/td"))//Get Comments
							{
								commentCount = commentCount + 1;
							}
						}//Get last comment count

						log.info("Row size of commentCount :"+commentCount);

						for(int k=commentCount; k>0; k--)//NB PRS ReworkDate:
						{
							secondLineCmt = "";
							String temp = "";

							getLastNBPrsComment = webHandler.getByxPath("//*[@id='dtlstThreadNotes']/tbody/tr["+k+"]/td");
							log.info("Get Last NBPRS Comment :"+getLastNBPrsComment);

							if(getLastNBPrsComment.contains("NB PRS ReworkDate: "+todaysDate))//Check cmt and date
							{
								String[] cmtSplt = getLastNBPrsComment.split("\\n");
								int cmtSize = cmtSplt.length;
								log.info("Comment Len :"+cmtSize);

								if(cmtSize > 1)
								{
									for(int c=1; c<cmtSize; c++)
									{
										temp = cmtSplt[c] +" ";
										secondLineCmt = secondLineCmt + temp;
									}
									log.info("Comment is :"+secondLineCmt);

									if(secondLineCmt.contains("NB NTU"))
									{
										log.info("NB NTU Comment Found");
										break;
									}else
									{
										log.info("NB NTU Comment Not Found");
									}
								}else
								{
									log.info("Comment Line is blank");
								}

							}else
							{
								if(!getLastNBPrsComment.contains(todaysDate))
								{
									log.info("NB PRS Rework comment not found in todays comments :"+getLastNBPrsComment);
									break;
								}
							}//End of check cmt and date
						}//For Loop

						Thread.sleep(500);  
						webHandler.clickByJavaExecutorXpath("//*[@id='TabStrip1_Item2_TCnt']", 30);//Click on Notes
						log.info("Clicked on Notes Tab");

						Thread.sleep(500);
						webHandler.switchToFrame("iframe1");//Frame Switch

						if(secondLineCmt.contains("NB NTU"))
						{			
							log.info("-----------------------NB NTU Process Flow----------------------------");

							VyomSeleniumHandler.driver.findElement(By.xpath("//*[@id='RichTextEditor1_frame']")).sendKeys(Keys.chord(Keys.CONTROL, "a"),"NB NTU ");//Write Comments as "Send to NTU".
							//webHandler.sendByxpath("//*[@id='RichTextEditor1_frame']","NB NTU", 30);//Write Comments as "Send to NTU".
							Thread.sleep(1000);
							log.info("Inside NB NTU, Write Send to NTU in comment box ");

							webHandler.clickByXpath("//*[@id='TabStrip1_Item1_TCnt']", 30);//Click on Job Commands
							log.info("Clicked on Job Commands Tab");

							checkDropDownValue = webHandler.getDropDownBoxValueByName("ddlPhases", "NB NTU", log);//Check the value
							if(checkDropDownValue.equalsIgnoreCase("Option Name Found"))
							{
								webHandler.selectDropDownByName("ddlPhases", "NB NTU", 30);//Select NB NTU

								Thread.sleep(2000);
								handleAlert_Dismiss(log);

								if(VyomSeleniumHandler.driver.findElement(By.xpath("//*[@id='btnJobDone']")).isEnabled())//Check the Job Done button
								{							
									webHandler.clickByXpath("//*[@id='btnJobDone']", 30);//Click on Job Done
									log.info("NB NTU dropdown selected, case processed");
									remark = "Case Processed Successfully";
								}else
								{
									if(webHandler.checkXpath("//*[@id='P_Ctrl_Status1_Panel1']/table/tbody/tr[1]/td"))//Check Remark
									{
										String errorRemark = "";
										errorRemark = webHandler.getByXpath("//*[@id='P_Ctrl_Status1_Panel1']/table/tbody/tr[1]/td", 30);//Get Error Remark
										log.info("Combo Case Error in NTU:"+errorRemark);

										if(errorRemark.contains("Combo Case, all proposals not completed this phase,Please choose "+"\"NB PRS Checker Combo\""+" Decision"))
										{
											webHandler.selectDropDownByName("ddlPhases", "NB PRS Checker Combo", 30);//Select NB PRS Checker Combo
											Thread.sleep(2000);

											webHandler.clickByXpath("//*[@id='btnJobDone']", 30);//Click on Job Done
											log.info("By using combi flow in NTU, Case has Processed Successfully");
											remark = "Case Processed Successfully";
										}else
										{
											remark = errorRemark;
											VyomSeleniumHandler.driver.close();
										}
									}
								}//NTU Combo Error Check											
							}else
							{
								log.info("NB NTU option not found in dropdown");
								remark = checkDropDownValue+" :NB NTU";
								VyomSeleniumHandler.driver.close();
							}
						}else
						{			
							log.info("----------------------Normal Case Flow-------------------------");

							VyomSeleniumHandler.driver.findElement(By.xpath("//*[@id='RichTextEditor1_frame']")).sendKeys(Keys.chord(Keys.CONTROL, "a"),"Done ");//Write Comments as "Done //webHandler.sendByxpath("//*[@id='RichTextEditor1_frame']","Done ", 30);//Write Comments as "Done".//webHandler.sendByxpath("//*[@id='RichTextEditor1_Center']","Done ", 30);//Write Comments as "Done
							Thread.sleep(1000);
							log.info("Normal Case, Write Done in comment box ");

							webHandler.clickByXpath("//*[@id='TabStrip1_Item1_TCnt']", 30);//Click on Job Commands

							checkDropDownValue = webHandler.getDropDownBoxValueByName("ddlPhases", "Sent to Dedupe", log);//Check the value
							if(checkDropDownValue.equalsIgnoreCase("Option Name Found"))
							{
								webHandler.selectDropDownByName("ddlPhases", "Sent to Dedupe", 30);//Sent to Dedupe

								Thread.sleep(2000);								
								handleAlert_Dismiss(log);

								if(VyomSeleniumHandler.driver.findElement(By.xpath("//*[@id='btnJobDone']")).isEnabled())//Check the Job Done button
								{
									webHandler.clickByXpath("//*[@id='btnJobDone']", 30);//Click on Job Done
									log.info("By using normal flow case processed successfully");
									remark = "Case Processed Successfully";
								}else
								{
									if(webHandler.checkXpath("//*[@id='P_Ctrl_Status1_Panel1']/table/tbody/tr[1]/td"))//Check Remark
									{
										String errorRemark = "";
										errorRemark = webHandler.getByXpath("//*[@id='P_Ctrl_Status1_Panel1']/table/tbody/tr[1]/td", 30);//Get Error Remark
										log.info("Combo Case Error :"+errorRemark);

										if(errorRemark.contains("Combo Case, all proposals not completed this phase,Please choose "+"\"NB PRS Checker Combo\""+" Decision"))
										{
											webHandler.selectDropDownByName("ddlPhases", "NB PRS Checker Combo", 30);//Select NB PRS Checker Combo

											Thread.sleep(2000);
											handleAlert_Dismiss(log);

											webHandler.clickByXpath("//*[@id='btnJobDone']", 30);//Click on Job Done
											log.info("By using combi flow, Case has Processed Successfully");
											remark = "Case Processed Successfully";
										}else
										{
											remark = errorRemark;
											VyomSeleniumHandler.driver.close();
										}
									}
								}//Combo Error Check
							}else
							{
								remark = checkDropDownValue+" :Sent to Dedupe";
								VyomSeleniumHandler.driver.close();
							}
						}//Else		
					}else
					{
						PRS_Checker_Main.urlChange = true; 
						log.info("URL Change flag :"+ PRS_Checker_Main.urlChange);
						remark = "Ione Site Is Down Server Error Found";
						VyomSeleniumHandler.driver.close();
						log.info("Ione Site Is Down Server Error Found Exception thrown");
						throw new Exception();
					}//Pannel Opn Check
				}else
				{
					PRS_Checker_Main.urlChange = true; 
					log.info("URL Change flag :"+ PRS_Checker_Main.urlChange);
					remark = "Ione Site Is Down Server Error Found";
					VyomSeleniumHandler.driver.close();
					log.info("Ione Site Is Down Server Error Found Exception thrown");
					throw new Exception();
				}//Frame Check
			}else
			{
				remark = "WorkFlow Pannel Not Open/Login screen found";
				log.info("Exception thrown due to WorkFlow Pannel Not Open");
				VyomSeleniumHandler.driver.close();
				log.info("WorkFlow Pannel Not Open Exception thrown");
				throw new Exception();
			}//End of pannelCheck
		}catch(Exception e)
		{
			remark = "Erorr in workflow pannel processing";
			log.info("Erorr in Workflow Job Panel Processing :"+e);
			throw e;
		}
		return remark;
	}//End of jobsCommandsAndNotes()

	public static boolean waitForNewWindow(int timeout, Logger log)
	{
		boolean flag = false;
		int counter = 0;
		while(!flag)
		{
			try 
			{
				Set<String> winId = VyomSeleniumHandler.driver.getWindowHandles();
				if(winId.size() > 1)
				{
					log.info("New Window found :"+winId);
					flag = true;
					return flag;
				}
				Thread.sleep(1000);
				counter++;
				if(counter > timeout)
				{
					return flag;
				}
			} catch (Exception e) 
			{
				log.info("Error in waitForNewWindow: "+e);
				return false;
			}
		}
		return flag;
	}//End of waitForNewWindow

	public static void textFileRemarkWrite(String remark, Logger log) throws Exception
	{
		if(!remark.equals(""))
		{
			File fileIs = new File(VyomSeleniumHandler.getProperties("RemarkTXTFile"));
			if(fileIs.createNewFile())
			{
				log.info("TXT File is created");
				Thread.sleep(1000);
			}

			FileOutputStream out = new FileOutputStream(VyomSeleniumHandler.getProperties("RemarkTXTFile")); 
			try
			{
				out.flush();
				out.write(remark.getBytes());//out.write(remark.getBytes(),0,remark.length());
				out.close();
				log.info("TXT File Writting done :"+remark);

			}catch(Exception e)
			{
				log.info("Error in TXT file writting :"+e);
			}
		}else
		{
			log.info("While file writting remark was Blank");
		}
	}//End of textFileRemarkWrite()

	public static boolean mouseMoveEventClick(String mainElementXpath, String moveToElementXpath, Logger log)
	{
		boolean mouseClickEvent = false;
		try
		{
			Actions action = new Actions(VyomSeleniumHandler.driver);
			WebElement we = VyomSeleniumHandler.driver.findElement(By.xpath(mainElementXpath));
			action.moveToElement(we).moveToElement(VyomSeleniumHandler.driver.findElement(By.xpath(moveToElementXpath))).click().build().perform();
			mouseClickEvent = true;
			Thread.sleep(1500);

		}catch(Exception e)
		{
			log.info("Error in Mouse Move Clicking :"+e);
			mouseClickEvent = false;
		}
		return mouseClickEvent; 

	}//End of mouseMoveClick()  

	public static void logOut(Logger log) throws Exception
	{
		try
		{
			webHandler.clickById("lnkLogin", 30);//Logout
			Thread.sleep(500);
			log.info("LogOut");
			webHandler.clearDriverInstances();

		}catch(Exception e)
		{
			log.info("Error in logOut :"+e);
		}

	}//End of logOut()

	public static void dismiss_Alert1(Logger log)
	{	
		try{
			new WebDriverWait(VyomSeleniumHandler.driver,2).ignoring(NoAlertPresentException.class).until(ExpectedConditions.alertIsPresent());
			Alert alertOK = VyomSeleniumHandler.driver.switchTo().alert();
			log.info("Alert is: "+alertOK.getText());
			alertOK.dismiss();
		}catch(Exception e){}
	}//End of acceptAlert()

	public static void handleAlert_Dismiss(Logger log)
	{
		if(isAlertPresent()){
			Alert alert = VyomSeleniumHandler.driver.switchTo().alert();
			log.info("Alert Is :"+alert.getText());
			alert.dismiss();
		}else
		{
			log.info("Alert not present");
		}
	}//End of handleAlert

	public static boolean isAlertPresent()
	{
		try{
			VyomSeleniumHandler.driver.switchTo().alert();
			return true;

		}catch(NoAlertPresentException ex)
		{
			return false;
		}
	}//End of isAlertPresent

}//End of Login()
