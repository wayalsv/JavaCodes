package kli.org.ione.pr01;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import all.org.vyomlibrary.VyomSeleniumHandler;

public class PRS_Checker_Main 
{
	static VyomSeleniumHandler webHandler = new VyomSeleniumHandler();
	public static Logger log = Logger.getLogger(PRS_Checker_Main.class.getName());//log file object
	static FileHandler fh = null;
	static boolean urlChange = false;

	public static void createLogFile() throws Exception
	{
		SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy_HHmmss");
		fh = new FileHandler("LogFiles/PRS_Checker_" + format.format(Calendar.getInstance().getTime()) + ".log");
		fh.setFormatter(new SimpleFormatter());
		log.addHandler(fh);
	}//End of createLogFile()

	public static void main(String[] args) throws Exception 
	{			
		String userName = args[0];
		String passWord = args[1];	

		String allocationUserName = "KLI BOT (LO5005)";
		String loginRemark = "";
		String tsarBandProcRemark = "";
		String remark = "";
		
		urlChange = false;

		//webHandler.clearDriverInstances();
		createLogFile();

		boolean reProcess = true;
		int reTryCnt = 0;

		while(reProcess && reTryCnt <= Integer.parseInt(VyomSeleniumHandler.getProperties("reTryCount")))
		{
			try
			{
				log.info(" :---------------------------------------Start Process----------------------------------------: ");
				webHandler.clearDriverInstances();
				webHandler.getDriver();

				loginRemark = PRS_IOne.login(userName, passWord, log);//Calling function
				log.info("I_One login Remark :"+loginRemark);

				if(loginRemark.equalsIgnoreCase("Login Successfully"))	
				{	
					tsarBandProcRemark = PRS_IOne.tsarBandQueueProcessing(allocationUserName, log);//Calling function	
					log.info("TSAR Band Queue Processing Remark: "+tsarBandProcRemark);

					PRS_IOne.textFileRemarkWrite(tsarBandProcRemark, log);
					reProcess = false;
					PRS_IOne.logOut(log);
					log.info(" :------------------------------------------End Process------------------------------------------: ");
				}else
				{
					remark = loginRemark;
					PRS_IOne.textFileRemarkWrite(remark, log);
					log.info("Process Terminated due to :"+loginRemark);
					webHandler.clearDriverInstances();
					System.exit(-1);					
				}			
			}catch(Exception e)
			{
				log.info(":-----------------------------Retry Count :"+reTryCnt+"------------------------------:");
				reTryCnt ++;
				log.info("Error in Main :"+e);
				webHandler.clearDriverInstances();
			}//End of try

			if(reTryCnt == Integer.parseInt(VyomSeleniumHandler.getProperties("reTryCount")))
			{
				try 
				{
					log.info("I-One Site Not Working/Down");	
					PRS_IOne.textFileRemarkWrite("I-One Site Not Responding/Down", log);
					webHandler.clearDriverInstances();//clearing ie instance
					System.exit(-1);
				} catch (Exception e) 
				{
					log.info("Error in Mail send :"+e);
				}
			}// End of retryCnt

		}//End of while
		webHandler.clearDriverInstances();
	}//End of Main
}//End of CLass
